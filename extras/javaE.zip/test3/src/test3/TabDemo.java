package test3;

/*https://docs.oracle.com/javase/tutorial/uiswing/examples/layout/TabDemoProject/src/layout/TabDemo.java*/
/*https://coderanch.com/t/340772/java/convert-Console-App-GUI
https://examples.javacodegeeks.com/desktop-java/swing/jtextfield/create-read-only-non-editable-jtextfield/
https://stackoverflow.com/questions/25513711/how-to-make-my-textfield-bigger-for-gui-in-java
*/
/*
 * TabDemo.java
 */

import java.awt.*;
import javax.swing.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public 
    class TabDemo extends JFrame
    {
    	private ArduinoClass template;
    	private JTextField []textBoxes;
      public GUI()
      {
    	 
    	//loadFile();
        setLocation(400,300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JPanel jp = new JPanel(new GridLayout(10,80));//was 4 1
    	//header label
    	JLabel lb0 = new JLabel("Welcome to the Arduino Library Template Maker");   
    	jp.add(lb0);
    	jp.add(new JLabel("please enter fields and press button"));
    	//body labels
    	String []fields={"className [Template]","author [John Doe]","organization [Brandeis Univeristy]","headerComments [This class...]","supportedBoards [ARDUINO_AVR_UNO]","variables [long time]","publicMethods [int|resetTime|resets the time]time=0;"};
    	String[]examples= {"Timer","Jacob Smith","Brandeis Robotics Club","A timer class to allow the user to create loops and maintain program control","ARDUINO_AVR_UNO ESP8266_WEMOSD1R1","long time","long|initTime|millis();\n\nlong|resetTime|resets the Initial Time|\ninitTime=millis();\nreturn getTime();\n\n"};
    	textBoxes= new JTextField[fields.length+1];
    	for (int i=0;i<fields.length;i++){
    		createField(fields,examples,i,jp);
    	}
    	

    	//output text field
    	JButton btn = new JButton("Please enter fields to edit Arduino class from template");
        btn.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent ae){
            updateClass();}}); ;
    	jp.add(btn);  
    	
    	//JLabel lb3 = new JLabel("Output of Class");
    	//jp.add(lb3);
    	final JTextArea tf3 = new JTextArea(5,20);
    	tf3.setEditable(false);
        jp.add(tf3);
    	 
        getContentPane().add(jp);
        pack();
    	
    	


    /*Creates a label and text box for a given field*/
    private void createField(String [] fields,String []examples,int index,JPanel jp){
    	JLabel lbl = new JLabel("Please enter "+fields[index]+" here");
    	final JTextField tf = new JTextField(10);
    	textBoxes[index]=tf;
    	tf.setText(examples[index]);
    	jp.add(lbl);
    	jp.add(tf);
    }
    public void updateClass(){
    	JPanel card2 = new JPanel();
        card2.add(new JTextArea(20, 20));
        jframe.setContentPane(your_new_panel);
        jframe.invalidate();
        jframe.validate();
    	System.out.println("mark");
    }
    }

    /////////////////////////////////////////////////
}